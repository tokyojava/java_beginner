package www.aic.lesson5.oop;

public class Person {
	public String name;
	public int age;

	public void introduce() {
		System.out.println("hi i am " + name + ":" + age) ;
	}

	public static void main(String[] args) {
		Person person = new Person();
		person.introduce();
		person.name = "xiaolu";
		person.age = 50;
		person.introduce();

	}
}
