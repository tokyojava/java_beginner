package www.aic.lesson5;

public class SwapTest {
	public static void main(String[] args){
	    int num1 = 1, num2 = 2;
	    System.out.println("before swap:" + num1 + "," + num2);
	     swap(num1,num2);
	     System.out.println("after swap:" + num1 + "," + num2);
	}

	public static void swap(int n1,int n2){
	      System.out.println("in function,before swap:" + n1 + "," + n2);
	      int temp = n1;
	      n1 = n2;
	      n2 = temp;
	      System.out.println("in function,after swap:" + n1 + "," + n2);
	}
}
