package www.aic.lesson5;

public class FunctionTest {
	
	public static void main(String[] args) {
		int arr[] = new int[3];
		
		//生成随机数
		for(int i = 0;i < arr.length;i++){
			arr[i] = generateRandomNumber(1000000);
			System.out.println("current random number is " + arr[i]);
		}
		
		boolean isPositive = isPositiveArray(arr);
		System.out.println("Current arr is positive?" + isPositive);
		
	}
	
	public static int generateRandomNumber(int range){
		int minus = 0;
		if((int)(Math.random() * 2) == 0 ){
			minus = -1;
		}
		else{
			minus = 1;
		}
		return minus * (int) (Math.random() * range);
	}

	public static boolean isPositiveArray(int[] arr) {
		int sumUp = sum(arr);
		if (sumUp > 0)
			return true;
		else {
			return false;
		}
	}
	
	public static int sum(int[] arr){
		int sum = 0;
		for (int i = 0; i < arr.length; i++) {
			sum += arr[i];
			//System.out.println("current index is " + i);
		}
		
		//temp = arr[i]
		for (int temp : arr) {
			sum += temp;
		}
		return sum;
	}

}
