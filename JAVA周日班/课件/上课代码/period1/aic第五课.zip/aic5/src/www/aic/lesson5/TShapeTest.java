package www.aic.lesson5;

public class TShapeTest {
	public static void main(String[] args) {
		int top = 10;
		int bottom = 20;
		double height = 100;
		System.out.println("curret area is " + getTShapeArea(top, bottom, height));
	}
	
	public static double getTShapeArea(double top,double bottom,double height){
		return (top + bottom) * height / 2;
	}
}
