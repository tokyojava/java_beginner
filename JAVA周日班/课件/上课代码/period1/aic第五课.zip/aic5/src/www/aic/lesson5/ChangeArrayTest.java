package www.aic.lesson5;

public class ChangeArrayTest {
	public static void main(String[] args) {
		int arr[] = new int[]{17,4};
		int b = 20;
		changeArray(arr, b);
		System.out.println(arr);
		printArray(arr);
		System.out.println(b);
	}
	
	public static void changeArray(int arr[],int b){
		for(int i = 0;i < arr.length;i++){
			arr[i] *= 2;
		}
		b = 100;
	}
	
	public static void printArray(int arr[]){
		for(int element: arr){
			System.out.print(element + " ");
		}
		System.out.println();
	}
}
