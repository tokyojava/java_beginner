package www.aic.lesson5;

public class NoReturnTypeTest {
	
	public static void main(String[] args) {
		printLevel(100);
	}
	
	public static void printLevel(int score){
		if(score < 60){
			System.out.println("fail");
		}
		else if(score <= 80){
			System.out.println("good");
		}
		else{
			System.out.println("excellent");
		}
		return;
	}

}
