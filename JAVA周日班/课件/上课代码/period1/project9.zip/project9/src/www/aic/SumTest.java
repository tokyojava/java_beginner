package www.aic;

import javax.swing.JOptionPane;

public class SumTest {
	public static void main(String[] args) {
		
		int sum = 0;
		String str = args[0];
		System.out.println(str);
		String[] arrs = str.split(" ");
		for(String arr:arrs){
			sum += Integer.parseInt(arr);
		}
		
		JOptionPane.showMessageDialog(null, sum);
	}
}
