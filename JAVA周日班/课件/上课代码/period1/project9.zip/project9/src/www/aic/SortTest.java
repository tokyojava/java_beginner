package www.aic;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortTest {

	
	public static void main(String[] args) {
		
		List list = new ArrayList();
		
		list.add(10);
		list.add(123);
		list.add(-100);
		
		Collections.sort(list);
		System.out.println(list);
		
		System.out.println(list.size());
	}
}
