package www.aic;

public class InterfaceTest {
	public static void main(String[] args) {
		Person persons[] = new Person[2];
		persons[0] = new Chinese();
		persons[1] = new WolfPerson();

		for (Person p : persons) {
			if (p instanceof Speakable) {
				Speakable s = (Speakable) p;
				s.say();
			}
		}

	}
}

abstract class Person {

}

class WolfPerson extends Person {

}

class Chinese extends Person implements Speakable {

	@Override
	public void say() {
		System.out.println("I can speak Chinese");
	}

}

interface Speakable {

	public static final String NAME = "Speaker";

	void say();
}
