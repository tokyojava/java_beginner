package www.aic;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class CountAlphabetic {
	public int countAlphabetic(String str) {
		int ret = 0;
		int length = str.length();
		for (int i = 0; i < length; i++) {
			char c = str.charAt(i);
			if (Character.isAlphabetic(c))
				ret++;
		}
		return ret;
	}

	public static void main(String[] args) {
		System.out.println("Please input a string:");
		Scanner scan = new Scanner(System.in);
		String input = scan.next();

		CountAlphabetic c = new CountAlphabetic();

		JOptionPane.showMessageDialog(null,
				"There are " + c.countAlphabetic(input)
						+ " alphabets in your input");

		scan.close();
	}
}
