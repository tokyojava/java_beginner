package www.aic;

public class PasswordCheck {
	public boolean checkPassword(String pwd) {
		if(pwd == null)
			return false;
		
		int length = pwd.length();
		if (length < 8)
			return false;
		else {
			
			boolean hasFindAlpha = false;
			int numericCount = 0;
			for(int i = 0;i < length;i++){
				char c = pwd.charAt(i);
				if(Character.isAlphabetic(c)){
					hasFindAlpha = true;
				}
				else if(Character.isDigit(c)){
					numericCount++;
				}
				else{
					return false;
				}
			}
			return hasFindAlpha && (numericCount >= 2);
		}
	}

	public static void main(String[] args) {
		PasswordCheck check = new PasswordCheck();

		String a = null;

		// 1000 lines

		System.out.println(check.checkPassword(a));

		// return false
		System.out.println(check.checkPassword("123"));
		// return true

		System.out.println(check.checkPassword("123456qc1"));

		// return false
		System.out.println(check.checkPassword("12345679"));
		// return false
		System.out.println(check.checkPassword("1dhajwhdjwqheq"));
		//return false
		System.out.println(check.checkPassword("12abcdef!"));
	}

}
