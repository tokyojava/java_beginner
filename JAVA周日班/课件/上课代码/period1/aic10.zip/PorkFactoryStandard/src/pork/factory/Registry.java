package pork.factory;

import java.util.ArrayList;
import java.util.List;

public class Registry {
	
	List factories = new ArrayList<>();
	
	public void add(PorkFactoryInterface newFactory){
		factories.add(newFactory);
	}
	
	
	public String getCheapestFactory(){
		double low = Double.MAX_VALUE;
		String name = "";
		
		for(Object obj:factories){
			PorkFactoryInterface factory = (PorkFactoryInterface) obj;
			if(factory.price() < low){
				low = factory.price();
				name = factory.getBrandName();
			}
		}
		return name;
	}
  
}
