package pork.factory;

public interface PorkFactoryInterface {

	String getBrandName();
	
	double price();
	
	String originalPlace();
	
}
