package pork.factory;

import java.util.ArrayList;
import java.util.List;

public class ListTest {

	public static void main(String[] args) {
		List list = new ArrayList();
		for (int i = 0; i < 10000; i++)
			list.add(i);
		// arr[index]
		System.out.println(list.get(100));
		// arr.length
		System.out.println(list.size());

		System.out.println("-------");
		System.out.println(list.get(0));
		list.remove(0);
		System.out.println(list.get(0));

	}

}
