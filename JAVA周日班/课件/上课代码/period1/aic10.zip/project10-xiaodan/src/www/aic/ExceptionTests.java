package www.aic;

import javax.swing.JFrame;


public class ExceptionTests {
	public static void main(String[] args) {
	//	String a = null;

		//1000 lines
		
		//System.out.println(a.length());
		
		
//		int arr[] = new int[10];
//		System.out.println(arr[10]);
//		Object a = new String("b");
//		System.out.println(((String)a).length());
//		
//		System.out.println(((JFrame)a).getAlignmentX());
		
		int a = 10 / 0;
		
		
	}
}
