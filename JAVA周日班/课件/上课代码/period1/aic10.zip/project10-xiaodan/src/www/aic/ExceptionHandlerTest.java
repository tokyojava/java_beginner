package www.aic;

import java.lang.Thread.UncaughtExceptionHandler;

public class ExceptionHandlerTest {

	public static void main(String[] args) {
		Thread.setDefaultUncaughtExceptionHandler(new MyExceptionHandler());
		
		System.out.println(1 / 0);
	}

}

class MyExceptionHandler implements UncaughtExceptionHandler{

	@Override
	public void uncaughtException(Thread t, Throwable e) {
		System.out.println("hahaha" + e);
	}
	
}
