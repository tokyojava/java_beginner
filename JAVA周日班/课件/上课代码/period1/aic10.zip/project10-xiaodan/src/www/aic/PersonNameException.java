package www.aic;

public class PersonNameException extends Exception{

	public PersonNameException(String name){
		super(name);
	}
}
