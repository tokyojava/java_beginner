package www.aic;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class InputNumberTest {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		int input = 0;
		try {
			System.out.println("Please input a number");
			input = scanner.nextInt();
		} catch (Exception e) {
			input = -1;
		}

		JOptionPane.showMessageDialog(null, "Your input is " + input);
		scanner.close();
	}
}
