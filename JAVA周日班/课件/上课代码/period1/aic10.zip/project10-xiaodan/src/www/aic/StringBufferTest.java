package www.aic;

public class StringBufferTest {
	public static void main(String[] args) {
		String str = "abc";
		String str2 = "cde";
		int num = 4;
		System.out.println(str + str2 + num);

		testPlusMark();
		testStringBuilder();

	}

	private static void testStringBuilder() {
		long now;
		long after;
		now = System.currentTimeMillis();
		StringBuilder builder = new StringBuilder();
		for (int i = 0; i < 10000; i++) {
			builder.append(i);
		}
		System.out.println(builder.toString());

		after = System.currentTimeMillis();

		System.out.println((after - now) / 1000.0 + "秒");
	}

	private static void testPlusMark() {
		String test = "";

		long now = System.currentTimeMillis();

		for (int i = 0; i < 10000; i++) {
			test += i;
		}
		System.out.println(test);

		long after = System.currentTimeMillis();

		System.out.println((after - now) / 1000.0 + "秒");
	}
}
