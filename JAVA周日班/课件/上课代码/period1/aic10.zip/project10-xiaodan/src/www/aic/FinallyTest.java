package www.aic;

public class FinallyTest {
	
	public static void main(String[] args) {
		try{
		int a = 10;
		System.out.println(a / 0);
		}finally{
			System.out.println("I am in finally");
		}
		
		System.out.println("aaaaa");
	}

}
