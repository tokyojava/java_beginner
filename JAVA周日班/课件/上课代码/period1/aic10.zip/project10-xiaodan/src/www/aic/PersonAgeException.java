package www.aic;

public class PersonAgeException extends RuntimeException{

	public PersonAgeException(String message){
		super(message);
	}
}
