package www.aic;

public class Person {
	private String name;
	private int age;

	public String getName() {
		return name;
	}
	
	public int getAge() {
		return age;
	}

	public void setName(String name) throws PersonNameException {
		if(name.length() < 1)
			throw new PersonNameException("Name is too short");
		this.name = name;
	}

	public void setAge(int age) {
		if (age < 0)
			throw new PersonAgeException("Age cannot be negative:" + age);
		this.age = age;
	}

	public static void main(String[] args) {
		Person p = new Person();
		try {
			p.setName("");
		} catch (PersonNameException e1) {
			System.out.println("Error occurred:" + e1.getMessage());
			System.out.println(e1);
		}
		p.setAge(10);
		try {
			p.setAge(-10);
		} catch (PersonAgeException e) {
			System.out.println("Error occurred:" + e.getMessage());
		}
	}

}
