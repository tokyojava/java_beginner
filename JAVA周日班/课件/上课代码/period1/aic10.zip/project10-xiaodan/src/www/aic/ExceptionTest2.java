package www.aic;

import java.io.IOException;

public class ExceptionTest2 {
	public static void main(String[] args) throws IOException {
		b();
	}
	
	public static void a(int i){
		if(i == 0)
			throw new IllegalArgumentException();
	}
	
	public static void b() throws IOException{
		throw new IOException();
	}
	
}
