package pork.factory;

public class Test {
	public static void main(String[] args) {
		Registry registry = new Registry();
		registry.add(new JapanesePorkFacoty());
		registry.add(new AmericaPorkFactory());
		
		System.out.println(registry.getCheapestFactory());
	}
}
