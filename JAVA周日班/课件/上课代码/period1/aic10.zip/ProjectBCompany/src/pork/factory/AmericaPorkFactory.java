package pork.factory;

public class AmericaPorkFactory implements PorkFactoryInterface {

	@Override
	public String getBrandName() {
		return "yanxuan";
	}

	@Override
	public String originalPlace() {
		return "America";
	}

	@Override
	public double price() {
		return 16;
	}

}
