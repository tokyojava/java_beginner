package pork.factory;

public class JapanesePorkFacoty implements PorkFactoryInterface {

	@Override
	public String getBrandName() {
		return "chunqing";
	}

	@Override
	public String originalPlace() {
		return "jiuzhou";
	}

	@Override
	public double price() {
		return 40;
	}

}
