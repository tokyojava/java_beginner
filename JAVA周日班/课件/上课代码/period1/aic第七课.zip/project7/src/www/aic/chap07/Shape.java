package www.aic.chap07;

public abstract class Shape {
	protected String color = "red";
	
	public Shape(){
		System.out.println("I am shape!!");
	}
	
	public Shape(String color){
		this.color = color;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void compareTo(Shape shape) {
		double area = this.getArea();
		double anotherArea = shape.getArea();
		if (area > anotherArea) {
			System.out.println("I am bigger");
		} else if (area < anotherArea) {
			System.out.println("I am smaller");
		} else {
			System.out.println("Equal");
		}

	}
	
	public void printType(){
		System.out.println("I am type Shape");
	}

	public abstract double getArea();
}
