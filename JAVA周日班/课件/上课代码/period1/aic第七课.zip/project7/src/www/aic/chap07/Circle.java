package www.aic.chap07;

/**
 * 要查看类中定义的方法或者域，按ctrl + o，
 * 要查看所有的（包括父类中继承过来的），按两次
 * @author qiucheng
 *
 */
public class Circle extends Shape{

	private double radius;
	

	public Circle() {
		this(10);
	}

	public Circle(double radius) {
		setRadius(radius);
		
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		if (radius < 0)
			return;
		this.radius = radius;
	}
	
	public double getArea() {
		return Math.PI * Math.pow(this.radius,2);
	}

}
