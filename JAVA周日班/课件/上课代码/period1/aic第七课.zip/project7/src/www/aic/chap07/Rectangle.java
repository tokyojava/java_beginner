package www.aic.chap07;

public class Rectangle extends Shape{
	private double width;
	private double height;
	
	public Rectangle(){
		this(10,10);
	}

	public Rectangle(double width, double height) {
		//super()可以不写，java编译器会自动加上，但是想要显式调用父类的另一个构造函数时，就要用这个语法
		super("yellow");
		this.width = width;
		this.height = height;
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getArea(){
		return this.getWidth() * this.getHeight();
	}
	
	public void printType(){
		super.printType();//this.printType()
		System.out.println("But I am also type Rectangle");
	}
	
}
