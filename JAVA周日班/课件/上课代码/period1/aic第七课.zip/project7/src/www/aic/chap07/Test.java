package www.aic.chap07;

public class Test {
	public static void main(String[] args) {
		System.out.println(new Object());
		
		//Shape s = new Shape();
		
		Shape c = new Circle(20);
		System.out.println(((Circle) c).getRadius());
		//下面两个方法是从Shape类继承而来的
		System.out.println(c.getColor());
		System.out.println(c.getArea());
		
		//这个方法是从java.lang.Object类继承而来的
		System.out.println(c.getClass());
		System.out.println(c.getColor());
		
		System.out.println("-------------------");
		Shape rec = new Rectangle(10,200);
		System.out.println(rec.getArea());
		System.out.println(rec.getColor());
		rec.printType();
		
		
		c.compareTo(rec);
		
		System.out.println("--------------");
		System.out.println(c instanceof Circle);
		System.out.println(c instanceof Rectangle);
		System.out.println(c instanceof Shape);
		
		
	}
}
