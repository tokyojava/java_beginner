package www.aic.class8;

/**
 * String a = “a”; 
 * String b = new String(“a”); 
 * length()
 * charAt()
 * substring()
 * String.valueOf()
 * equals
 * equalsIgnoreCase 
 * startsWith
 * endsWith 
 * replace
 * indexOf
 */
public class StringTest {
  public static void main(String[] args) {
	  String a = "a"; 
	  String b = new String("i am at ikebukuro sunshine city");
	  
	  System.out.println("b's length is " + b.length());
	  System.out.println("b' last character is " + b.charAt(b.length() - 1));
	  
	  int length = b.length();
	  for(int i = 0;i < length;i++){
		  System.out.print(b.charAt(i) + " ");
	  }
	  System.out.println();
	  
	  //字串
	  System.out.println(b.substring(1));
	  
	  System.out.println(b.substring(5,7));
	  
	  System.out.println(getReveresedInteger(12345));
	  
	  System.out.println(String.valueOf(true));
	  
	  String str1 = new String("abcd");
	  String str2 = new String("abcd");
	  System.out.println(str1 == str2);
	  System.out.println(str1.equals(str2));
	  
	  String str3 = "Abcd";
	  System.out.println(str1.equals(str3));
	  System.out.println(str1.equalsIgnoreCase(str3));
	  
	  //前缀
	  String prefix = "java";
	  //后缀
	  String suffix = "world";
	  String testStr = "java hello world";
	  
	  System.out.println(testStr.startsWith(prefix));
	  System.out.println(testStr.endsWith(suffix));
	  
	  String testStr1= "test";
	  testStr1 = testStr1.replace('t', 'f');
	  System.out.println(testStr1);
	  
	  String indexStr = "hello";
	  
	  System.out.println(indexStr.indexOf('l'));
	  System.out.println(indexStr.lastIndexOf('l'));
  }
  
  /**
   * 输入是12345，输出是54321
   * @param param
   * @return
   */
  public static int getReveresedInteger(int param){
	  String paramStr = String.valueOf(param);
	  
	  int length = paramStr.length();
	  String resultStr = "";
	  
	  for(int i = length - 1;i >= 0;i--){
		  resultStr += paramStr.charAt(i);
	  }
	  
	  return Integer.parseInt(resultStr);
  }
}
