package www.aic.class8;

/**
 * floor, ceil round abs max sqrt
 */
public class MathTest {
	public static void main(String[] args) {
		double test = 2.678;
		System.out.println(Math.floor(test));
		System.out.println(Math.ceil(test));
		System.out.println(Math.round(test));
		System.out.println(Math.abs(-1.02));
		System.out.println(Math.sqrt(9.61));
	}
}
