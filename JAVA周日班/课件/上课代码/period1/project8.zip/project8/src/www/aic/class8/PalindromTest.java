package www.aic.class8;

public class PalindromTest {
	
	public static void main(String[] args) {
		//true,true,false
		System.out.println(isPalindrome("sagas"));
		System.out.println(isPalindrome("abccba"));
		System.out.println(isPalindrome("aabbdc"));
	}
	
  public static boolean isPalindrome(String str){
	  int length = str.length();
	  int low = 0;
	  int high = length - 1 - low;
	  while(low < high){
		  if(str.charAt(low) != str.charAt(high))
			  return false;
		  low++;
		  high--;
	  }
	return true;  
  }
}
