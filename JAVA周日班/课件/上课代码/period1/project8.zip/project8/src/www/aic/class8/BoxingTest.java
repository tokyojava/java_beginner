package www.aic.class8;

public class BoxingTest {
	public static void main(String[] args) {
		Integer a = 12345;//int a = 12345;	
		System.out.println(a.doubleValue());
		
	}
}
