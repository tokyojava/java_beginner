package www.aic.class8;

/**
 * 重写equals和toString，并且讲解==和equals的区别 
 *
 */
public class Person {
	private String name;
	private int age;
	private String phoneNumber;

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Person(String name, int age,String telephone) {
		super();
		this.name = name;
		this.age = age;
		this.phoneNumber = telephone;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public boolean equals(Object o) {
		if (o == null) {
			return false;
		}
		if (o instanceof Person) {
			Person anotherPerson = (Person) o;
			return this.name.equals(anotherPerson.name)
					&& this.age == anotherPerson.age;
		} else {
			return false;
		}
	}
	
	public String toString(){
		return this.name + " and I am " + this.age + " years old and my phone number " + this.phoneNumber;
	}

	public static void main(String[] args) {

		Person p = new Person("xiaolu", 20,"010");
		Person p2 = p;

		Person p3 = new Person("xiaolu", 20,"010");

		int a = 1;
		int b = 10 - 9;
		// 原始类型可以用==去做判断
		System.out.println("a == b " + (a == b));

		System.out.println("p is equal to p3? " + p.equals(p3));

		System.out.println("p==p2 " + (p == p2));
		System.out.println("p==p3 " + (p == p3));

		System.out.println(2 - 0.1);

		System.out.println(p3);
		System.out.println(p.getClass().getName());
		System.out.println(p.getClass().getSimpleName());
		
		int arr[] = new int[]{1,2,3};
		System.out.println(" 肯定是乱码 " + arr);
		for(int i:arr){
			System.out.print(i + " ");
		}

	}

}
