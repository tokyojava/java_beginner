package www.aic.class8;

import javax.swing.JOptionPane;

public class CalculatorTest {
	public static void main(String[] args) {
		String input1 = JOptionPane.showInputDialog(null, "please input a number");
		String input2 = JOptionPane.showInputDialog(null, "please input another number");
		String operatorStr = JOptionPane.showInputDialog(null,"please input an operator");
		int a = Integer.parseInt(input1);
		int b = Integer.parseInt(input2);
		int c = 0;
		
		char op = operatorStr.charAt(0);
		if(op == '+'){	
			c = a + b;
		}
		else if(op == '-'){
			c = a - b;
		}
		
		JOptionPane.showMessageDialog(null, "The sum of the two numbers is " + c);
	}
}
