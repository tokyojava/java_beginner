package www.aic.class8;

public class ParsePerson {

	public static void main(String[] args) {
		System.out.println(parsePersonFromString("xiaolu-20-08012345678"));
	}
	
	public static Person parsePersonFromString(String personStr){
		String[] params = personStr.split("-");
		String name = params[0];
		int age = Integer.parseInt(params[1]);
		String telephone = params[2];
		Person ret = new Person(name, age, telephone);
		return ret;
	}
}
