package www.aic.class8;

public class CharTest {
	public static void main(String[] args) {
		char A = 'A';//65
		char a = 'a';//97
		char b = (char) (a + 1);
		
		System.out.println(a + 1);
		System.out.println(b);
		
		int[] status = new int[26];
		
		String str = "abc";
		char input = str.charAt(2);
		status[input - 'a']++;
		
	}
}
