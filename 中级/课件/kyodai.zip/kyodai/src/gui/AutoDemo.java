package gui;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Map;

import javax.swing.JPanel;

import constants.GUIConstant;

import util.EventManager;
import util.Rules;

public class AutoDemo implements ActionListener,GUIConstant {

	@Override
	public void actionPerformed(ActionEvent e) {
		if(p == null)
			return;
		if(p.getComponentCount() == 0)
			return;
		gui.Main.auto_mode = true;
		gui.Main.bar.setValue(time_scale);
		Thread t = new Thread() {
			@SuppressWarnings("deprecation")
			public void run() {
				Map<LinkedList<Point>, LinkedList<MainPanel>> list;
				EventManager manager = new EventManager();
				while ((list = Rules.getRandomDeletion(EventManager.str, p)) != null) {
					deleteOnce(list, manager);
				}
				EventManager.t.stop();
				EventManager.o.stop();
				EventManager.gameOverRestore(p);
			}
		};
		t.start();
	}

	/**
	 * this method automatically and randomly selects 2 identical and reachable
	 * card and delete them
	 * @param list      the point to be deleted
	 * @param manager     the Eventmanager Object
	 */
	public void deleteOnce(
			Map<LinkedList<Point>, LinkedList<MainPanel>> list,
			EventManager manager) {
		Map.Entry<LinkedList<Point>, LinkedList<MainPanel>> temp = list
				.entrySet().iterator().next();
		LinkedList<Point> key = temp.getKey();
		LinkedList<MainPanel> value = temp.getValue();
		manager.del(EventManager.str,AutoDemo.this.p, key, value.get(0), value.get(1));
		try {
			Thread.sleep(AUTO_DELETE_SPEED);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public AutoDemo(JPanel p) {
		this.p = p;
	}

	private JPanel p;
}
