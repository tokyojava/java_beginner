package gui;

import java.awt.Graphics;
import java.awt.Image;
import java.io.File;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

import util.EventManager;
import constants.GUIConstant;

public class MainPanel extends JButton {

	public String url;
	public JPanel frame;
	private static final long serialVersionUID = -1338667286827753432L;

	public MainPanel(){
	}
	
	public MainPanel(String url, int x, int y, JPanel frame) {
		this.url = url;
		this.frame = frame;
		this.setSize(GUIConstant.PIC_SIZE, GUIConstant.PIC_SIZE);
		this.setLocation(x, y);
		addMouseListener(EventManager.manager);
		validate();
		repaint();
	}

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Image image = new ImageIcon(url).getImage();
		g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(), frame);
	}
	
	public static void main(String[] args) {
	    File file = new File("llk/header.jpg");
        System.out.println(file.getAbsolutePath()); 		
	}
}
