package gui;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import record.Record;
import util.EventManager;
import util.FileCreater;
import util.FileManager;
import util.RecordReader;
import util.RegisterAll;
import constants.GUIConstant;

public class Main implements GUIConstant {

	public static JTextArea a;
	public static JProgressBar bar;
	public static JTextField showPoint;
	public static String curFile;
	public static int bomb_c = 3;
	public static int hint_c = 3;
	public static int reset_c = 3;
	public static JButton reset;
	public static JButton hint;
	public static JButton bomb;
	public static JTextField remain;
	public static int points = 0;
	public static ArrayList<Record> record;
	public static JMenuItem auto = null;
	public static boolean auto_mode = false;
	public static JMenuItem item = null;

	private static class MyStack {
		private Integer[] elements = new Integer[20];
		int count;

		public void push(Integer value) {
			count++;
			if (count > elements.length) {
				Integer temp[] = new Integer[elements.length * 2 + 1];
				for (int i = 0; i < elements.length; i++) {
					temp[i] = elements[i];
				}
				elements = temp;
			}
			elements[count - 1] = value;
		}

		public void pop() {
			elements[--count] = null;
			System.arraycopy(elements, 0, elements, 0, count);
		}

		public int size() {
			return count;
		}

		public int capacity() {
			return elements.length;
		}
	}

	public static void main(String[] args) throws IOException {
		init();
	}

	/**
	 * init method,does a lot of gui construction and mouse handlers
	 * 
	 * @throws IOException
	 */
	private static void init() throws IOException {
		record = Record.readFromFile();
		if (record == null) {
			record = new ArrayList<Record>();
		}
		// the main frame that holds everything
		final JFrame frame = new JFrame("������");
		frame.getRootPane().setBackground(Color.black);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocation(start_x, start_y);
		frame.setSize(Fr_x + advanced_x + 10, Fr_y + advanced_y);
		frame.setResizable(false);
		frame.setLayout(null);

		// the main panel that holds the card
		final JPanel panel = new JPanel() {
			private static final long serialVersionUID = 6540014567068834667L;

			public void paintComponent(Graphics g) {
				URL url = Main.class.getClassLoader().getResource(
						"llk/backMoon.jpg");
				Image image = new ImageIcon(url).getImage();
				g.drawImage(image, 0, 0, this.getWidth(), this.getHeight(),
						frame);
			}
		};

		panel.setLayout(null);
		panel.setLocation(0, 0);
		panel.setSize(Fr_x, Fr_y + advanced_y);
		panel.setBackground(Color.darkGray);
		Border border1 = BorderFactory.createLineBorder(Color.red, 5);
		panel.setBorder(border1);
		frame.add(panel);

		// the accessory side bar that holds some extra services
		final JPanel accessory = new JPanel();
		accessory.setLayout(null);
		accessory.setLocation(Fr_x + 1, 0);
		accessory.setSize(advanced_x + 5, Fr_y + advanced_y);
		accessory.setBackground(Color.YELLOW);
		frame.add(accessory);

		/**
		 * ���ñ����ָ�ÿ������
		 */
		Border border = BorderFactory.createBevelBorder(BevelBorder.RAISED,
				Color.black, Color.black);
		/**
		 * �������еı�ͷ
		 */
		JPanel header = new JPanel() {
			private static final long serialVersionUID = 7602917161374202962L;

			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				URL url = Main.class.getClassLoader().getResource(
						"llk/header.jpg");
				Image image = new ImageIcon(url).getImage();
				g.drawImage(image, 0, 0, advanced_x, header_height, null);
			}
		};
		header.setSize(advanced_x, header_height);
		header.setLocation(0, 0);
		header.repaint();
		accessory.add(header);

		/**
		 * �������еĵ���
		 */
		JPanel tool = new JPanel() {
			private static final long serialVersionUID = 7602917161374202962L;

			public void paintComponent(Graphics g) {
				super.paintComponent(g);
				URL url = Main.class.getClassLoader().getResource(
						"llk/tool.jpg");
				Image image = new ImageIcon(url).getImage();
				g.drawImage(image, 0, 0, advanced_x, tool_height, this);
			}
		};
		tool.setSize(advanced_x, tool_height);
		tool.setLocation(0, header_height + 5);
		tool.repaint();
		tool.setBorder(border);
		accessory.add(tool);

		/**
		 * �������еĵ�����
		 */
		JPanel toolbar = new JPanel();
		toolbar.setSize(advanced_x, tool_height);
		toolbar.setLocation(0, header_height + tool_height + 10);
		toolbar.repaint();

		toolbar.setBorder(border);
		accessory.add(toolbar);

		/**
		 * put tools into the tool bar
		 */
		hint = new JButton();

		URL hint_url = Main.class.getClassLoader().getResource("llk/hint.jpeg");
		hint.setIcon(new ImageIcon(hint_url));
		reset = new JButton();
		URL reset_url = Main.class.getClassLoader().getResource(
				"llk/reset.jpeg");
		reset.setIcon(new ImageIcon(reset_url));
		toolbar.setLayout(null);
		hint.setSize(tool_height, tool_height);
		reset.setSize(tool_height, tool_height);
		hint.setLocation(0, 0);
		reset.setLocation(tool_height + 1, 0);
		toolbar.add(hint);
		toolbar.add(reset);

		bomb = new JButton();
		URL bomb_url = Main.class.getClassLoader().getResource("llk/bomb.jpeg");
		bomb.setIcon(new ImageIcon(bomb_url));
		bomb.setSize(tool_height, tool_height);
		bomb.setLocation(tool_height * 2 + 2, 0);
		toolbar.add(bomb);

		JTextField point = new JTextField("����:");
		point.setSize(35, 30);
		point.setLocation(tool_height * 3 + 3, 0);
		point.setBackground(Color.yellow);
		point.setEditable(false);
		toolbar.add(point);

		remain = new JTextField("�վ�");
		remain.setHorizontalAlignment(JTextField.RIGHT);
		remain.setSize(70, 30);
		remain.setEditable(false);
		remain.setLocation(tool_height * 4, 0);
		remain.setBackground(Color.yellow);
		toolbar.add(remain);

		showPoint = new JTextField("������ʼ");
		showPoint.setHorizontalAlignment(JTextField.RIGHT);
		showPoint.setSize(80, 30);
		showPoint.setEditable(false);
		showPoint.setLocation(tool_height * 6 - 2 + 10, 0);
		showPoint.setBackground(Color.yellow);
		toolbar.add(showPoint);

		// ��JTextArea��ӡ���е���Ϸ��Ϣ
		a = new JTextArea("game info:");
		a.setEditable(false);
		JScrollPane pane = new JScrollPane(a);
		pane.setSize(advanced_x, ScrollPane_size);
		pane.setLocation(0, header_height + tool_height * 2 + 10);
		accessory.add(pane);
		accessory.validate();
		a.append("\nYou have got:\n" + Main.bomb_c + " bombs\n");
		a.append(Main.hint_c + " hints\n");
		a.append("and " + Main.reset_c + " resets\n");

		bar = new JProgressBar(0, time_scale);
		bar.setValue(time_scale);
		bar.setSize(advanced_x, 30);
		bar.setLocation(0, header_height + tool_height * 2 + ScrollPane_size
				+ 10);
		bar.setForeground(Color.red);
		bar.setStringPainted(true);
		bar.setString("�ȴ���Ϸ��ʼ");
		accessory.add(bar);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(Color.magenta);
		JMenu menu = new JMenu("������");
		URL menu_url = Main.class.getClassLoader().getResource(
				"llk/menu/flower.gif");
		menu.setIcon(new ImageIcon(menu_url));
		item = new JMenuItem("��ʼ");
		item.setEnabled(false);
		URL item_url = Main.class.getClassLoader().getResource(
				"llk/menu/start.gif");
		item.setIcon(new ImageIcon(item_url));
		menu.add(item);
		item.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String path = curFile;
				EventManager.gameBegin(frame, panel, path);
				auto.setEnabled(true);
			}
		});

		JMenuItem select = new JMenuItem("ѡ���ͼ");
		menu.add(select);
		URL select_url = Main.class.getClassLoader().getResource(
				"llk/menu/dakai.gif");
		select.setIcon(new ImageIcon(select_url));
		select.addActionListener(new FileManager());

		JMenuItem create = new JMenuItem("������ͼ���tɫ����o�ƣ�");
		menu.add(create);
		URL cre_url = Main.class.getClassLoader().getResource(
				"llk/menu/chuangjian.gif");
		create.setIcon(new ImageIcon(cre_url));
		FileCreater cre = new FileCreater();
		create.addActionListener(cre);

		JMenu file = new JMenu("�ļ�");
		URL file_url = Main.class.getClassLoader().getResource(
				"llk/menu/eclipse.gif");
		file.setIcon(new ImageIcon(file_url));
		JMenuItem rank = new JMenuItem("���а�");
		URL rank_url = Main.class.getClassLoader().getResource(
				"llk/menu/rank.gif");
		rank.setIcon(new ImageIcon(rank_url));
		file.add(rank);
		rank.addActionListener(new RecordReader());

		JMenu adv = new JMenu("�߼�");
		URL adv_url = Main.class.getClassLoader()
				.getResource("llk/menu/ad.gif");
		adv.setIcon(new ImageIcon(adv_url));
		auto = new JMenuItem("�Զ�������ʾ");
		adv.add(auto);
		URL auto_url = Main.class.getClassLoader().getResource(
				"llk/menu/auto.gif");
		auto.setIcon(new ImageIcon(auto_url));
		auto.addActionListener(new AutoDemo(panel));

		menuBar.add(adv);
		menuBar.add(menu);
		menuBar.add(file);
		frame.setJMenuBar(menuBar);

		// ע�����еİ�ť�ص�����
		RegisterAll.registerReset(panel, reset);
		RegisterAll.registerHint(panel, hint);
		RegisterAll.registerBomb(panel, bomb);

		reset.setEnabled(false);
		hint.setEnabled(false);
		bomb.setEnabled(false);
		frame.validate();
		frame.repaint();
		panel.repaint();
	}
}