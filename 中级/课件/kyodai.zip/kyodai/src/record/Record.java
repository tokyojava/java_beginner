package record;

import java.awt.HeadlessException;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Record implements Serializable{

	private static final long serialVersionUID = -3213320061963783384L;
	public String map;
	public int time;
	public String name;
	public int max;
	
	public static void writeToFile(ArrayList<Record> map) {
		if (map == null)
			return;
		else {
			try {
				ObjectOutputStream o = new ObjectOutputStream(
						new BufferedOutputStream(new FileOutputStream(
								"record.dat")));
				o.writeObject(map);
				o.flush();
				o.close();
				JOptionPane.showMessageDialog(null, "�ļ��ѱ���");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	@SuppressWarnings("unchecked")
	public static ArrayList<Record> readFromFile() {
		ArrayList<Record> obj = null;
		ObjectInputStream i = null;
		try {
			i = new ObjectInputStream(new BufferedInputStream(
					new FileInputStream("record.dat")));
			obj = (ArrayList<Record>) i.readObject();
		}

		catch (HeadlessException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "bad formatted record file���ļ�����,��" + new File("record.dat").getAbsolutePath() +"���ļ������");
			return null;
		} catch (EOFException e) {
			return null;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "�޼�¼�ļ�������" + new File(".").getAbsolutePath() + "�½�����Ϊ" +
					"record.dat�Ŀ��ļ�");
			return null;
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				if(i != null)
				    i.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return obj;
	}
}
