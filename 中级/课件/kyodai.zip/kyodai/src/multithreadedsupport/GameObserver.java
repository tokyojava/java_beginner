package multithreadedsupport;

import java.io.File;
import java.util.ArrayList;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import record.Record;
import util.EventManager;

public class GameObserver extends Thread{
	@SuppressWarnings("deprecation")
	public void run() {
		while (true) {
			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			if (panel.getComponentCount() == 0
					&& gui.Main.bar.getValue() > 0) {
				if(t != null)
				   t.stop();
				
				EventManager.gameOverRestore(panel);
				if (!gui.Main.auto_mode && panel.getComponentCount() == 0 && !TimeController.timeout) {
					String f = new File(gui.Main.curFile).getName();
					f = f.substring(0, f.indexOf('.'));
					
					//check whether this map has a previous record
					Record temp = null;
					ArrayList<Record> list = gui.Main.record;
					for(int i = 0;i < list.size();i++){
						Record t1 = list.get(i);
						if(t1.map.equals(f)){
							temp = t1;
							break;
						}
					}
					
					//�����ԭʼ�ɼ�����ô�ͱȽ��Ƿ��ԭʼҪ��
					if(temp != null){
						if(gui.Main.points < temp.time){
							JOptionPane.showMessageDialog(null, "������" + gui.Main.points + "�룬��ϲ�����˼�¼���õ�ͼ" +
									"��ԭ������óɼ���" + temp.time + "�룬�뱣��!");
							list.remove(temp);
							list.add(createNewRecord(f));
							Record.writeToFile(list);
						}
						else
							JOptionPane.showMessageDialog(null, "������" + gui.Main.points + "�룬�ܱ�Ǹ���õ�ͼ" +
									"����óɼ���" + temp.time + "�룬����Ŭ��!");
					}
					
					else{
						JOptionPane.showMessageDialog(null, "������" + gui.Main.points + "�룬�¼�¼�뱣��!");
						list.add(createNewRecord(f));
						Record.writeToFile(list);
					}
				}
				break;
			}
		}
	}

	private Record createNewRecord(String f) {
		Record r;
		r = new Record();
		r.map = f;
		r.time = gui.Main.points;
		r.max = Math.max(EventManager.hit, EventManager.max);
		String name = JOptionPane.showInputDialog("�������������");
		if(name == null)
			name = "�������";
		r.name = name;
		return r;
	}

	public GameObserver(Thread t,JPanel panel){
	      this.panel = panel;	
	      this.t = t;
	}
	
	//the panel that the observer observes
	private JPanel panel;
	//the thread controlled by this thread
	private Thread t;
}
