package multithreadedsupport;

import gui.Main;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

import util.EventManager;
import util.SoundManager;

public class TimeController extends Thread{
	public static boolean timeout;
	public void run() {
		while (Main.bar.getValue() != 0) {
			if(gui.Main.auto_mode)
				return;
			gui.Main.bar.setString(gui.Main.bar.getValue() + "��");
			gui.Main.points++;
			gui.Main.showPoint.setText(gui.Main.points + "���ȥ��");
			if (gui.Main.bar.getValue() <= 5)
				SoundManager.notify.play();
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
			}
			gui.Main.bar.setValue(gui.Main.bar.getValue() - 1);
		}
		timeout = true;
		JOptionPane.showMessageDialog(null, "game over");
		EventManager.gameOverRestore(panel);
	}
	
	public TimeController(JPanel panel){
	      this.panel = panel;	
	}
	
	//the panel that the timer spells on
	private JPanel panel;

}
