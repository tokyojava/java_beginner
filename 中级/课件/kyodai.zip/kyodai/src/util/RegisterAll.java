package util;

import gui.AutoDemo;
import gui.Main;
import gui.MainPanel;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Map;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.Border;

public class RegisterAll {
	public static void registerBomb(final JPanel panel,final  JButton bomb) {
		bomb.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Main.bomb_c--;
				if(Main.bomb_c == 0)
				   bomb.setEnabled(false);
				Main.a.append("����" + Main.bomb_c + "��ը��\n");
				Map<LinkedList<Point>, LinkedList<MainPanel>> map= Rules.getRandomDeletion(EventManager.str, panel);
				new AutoDemo(panel).deleteOnce(map, (EventManager) EventManager.manager);
				SoundManager.bomb.play();
			}
		});
	}

	/**
	 * @param panel,the panel that we put buttons
	 * @param reset  the button to be registered with a handler function
	 * ,reset all buttons in the table
	 */
	public static void registerReset(final JPanel panel, final JButton reset) {
		//���ע�ᰴť��������
		reset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Main.reset_c--;
				if(Main.reset_c == 0)
					  reset.setEnabled(false);
				Main.a.append("����" + Main.reset_c + "������\n");
				reset_mess(panel);
			}

		});
	}

		public static void reset_mess(final JPanel panel){
			int count = panel.getComponentCount();
			for (int i = 0; i < 1000; i++) {
				int r1 = (int) (Math.random() * count);
				int r2 = (int) (Math.random() * count);
				MainPanel p1 = (MainPanel) panel.getComponent(r1);
				MainPanel p2 = (MainPanel) panel.getComponent(r2);

				//modify the bitmap
				Point a = LocationManager.mapToCoordination(p1.getX(), p1
						.getY());
				Point b = LocationManager.mapToCoordination(p2.getX(), p2
						.getY());
				String str = EventManager.str[a.y][a.x];
				EventManager.str[a.y][a.x] = EventManager.str[b.y][b.x];
				EventManager.str[b.y][b.x] = str;

				//exchange position
				Point temp = new Point(p1.getX(), p1.getY());
				p1.setLocation(p2.getX(), p2.getY());
				p2.setLocation(temp);
			}
			SoundManager.flystar.play();
		}
		
	/**
	 * @param panel,the panel that we put buttons
	 * @param reset  the button to be registered with a handler function
	 */
	public static void registerHint(final JPanel panel, final JButton hint) {
		//���ע�ᰴť��������
		hint.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Main.hint_c--;
				if(Main.hint_c == 0)
					   hint.setEnabled(false);
				Main.a.append("����" + Main.hint_c + "����ʾ\n");
				LinkedList<MainPanel> list = LocationManager.getSolution(
						EventManager.str, panel);
				if (list != null && list.size() == 2) {
					final MainPanel p1 = list.get(0);
					final MainPanel p2 = list.get(1);
					Thread t = new Thread() {
						public void run() {
							Border border = BorderFactory.createLineBorder(
									Color.YELLOW, 10);
							p1.setBorder(border);
							p2.setBorder(border);
							try {
								Thread.sleep(2000);
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
							p1.setBorder(null);
							p2.setBorder(null);
						}
					};
					SoundManager.flystar.play();
					t.start();
					panel.repaint();
				} else
					JOptionPane.showMessageDialog(null, "�o����");
			}

		});
	}
}
