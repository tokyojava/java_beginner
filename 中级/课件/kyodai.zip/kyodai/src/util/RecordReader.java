package util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import record.Record;

public class RecordReader implements ActionListener {

	@Override
	public void actionPerformed(ActionEvent e) {
		final JFrame frame = new JFrame("�ɼ���¼");
		frame.setSize(330, 300);
		frame.setLocationRelativeTo(null);
		frame.addWindowListener(new WindowAdapter() {
			//���ô����������ı䴰�ڹرյ�Ĭ����Ϊ
			public void windowClosing(WindowEvent e) {
				frame.dispose();
			}
		});
		frame.setVisible(true);
		JTextArea a = new JTextArea();
		a.append("                         ���е�ͼ����óɼ��ǣ�\n");
		a.append("  ��ͼ\tʱ��\t���\t�������\n");
		a.append("---------------------------------------------------------------------" +
				"---------\n");
		a.setEditable(false);
		JScrollPane pane = new JScrollPane(a);
		frame.add(pane);
		ArrayList<Record> records = Record.readFromFile();
		if (records != null)
			     for (Iterator<Record> iterator = records.iterator(); iterator.hasNext();) {
					Record name = iterator.next();
				String append = "  ";
				append += name.map + "\t";
				append += name.time + "��\t";
				append += name.name + "\t";
				append += name.max + "\t";
				a.append(append + "\n");
			}
	}

}
