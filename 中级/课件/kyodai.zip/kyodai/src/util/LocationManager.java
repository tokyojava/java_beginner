package util;

import gui.MainPanel;

import java.awt.Point;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileFilter;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JPanel;

import constants.GUIConstant;

public class LocationManager implements GUIConstant {
	private static String[][] cur_map;
	private static LocationManager manager;

	private LocationManager() {
	}

	public static LocationManager getInstance() {
		if (manager != null && cur_map != null)
			return manager;
		else {
			cur_map = new String[vertical_max][horizontal_max];
			return manager = new LocationManager();
		}
	}

	public static void mess(String[][] str) {
		for (int i = 0; i < 10000; i++) {
			int y1 = (int) (Math.random() * horizontal_max);
			int x1 = (int) (Math.random() * vertical_max);

			int y2 = (int) (Math.random() * horizontal_max);
			int x2 = (int) (Math.random() * vertical_max);

			if (str[x1][y1] != null && str[x2][y2] != null) {
				String temp = str[x1][y1];
				str[x1][y1] = str[x2][y2];
				str[x2][y2] = temp;
			}
		}
	}

	/**
	 * @param str ����ͼƬ��λͼ
	 * @return �����ҵ��ĵ�һ�������ť������Ҳ���������null
	 */
	public static LinkedList<MainPanel> getSolution(String[][] bitmap,
			JPanel comp) {
		int count = comp.getComponentCount();
		LinkedList<MainPanel> list = null;

		for (int i = 0; i < count - 1; i++) {
			MainPanel temp = (MainPanel) comp.getComponent(i);
			for (int j = i + 1; j < count; j++) {
				MainPanel temp1 = (MainPanel) comp.getComponent(j);
				if (temp1.url.equalsIgnoreCase(temp.url)) {
					if (Rules.isReacheable(bitmap, temp, temp1)) {
						list = new LinkedList<MainPanel>();
						list.add(temp);
						list.add(temp1);
						return list;
					}
				}
			}
		}
		return null;
	}

	public String[][] buildMap(String mapConfig, String imageUrl)
			throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(mapConfig));
		String inline = "";
		int rows = 0;
		int count = 0;
		String cache = null;
		cur_map = new String[vertical_max][horizontal_max];

		while ((inline = reader.readLine()) != null) {
			inline = inline.substring(0, inline.lastIndexOf('0') + 1);
			if (inline.length() != horizontal_max)
				throw new IllegalStateException("��" + rows + "�г��ִ���");

			//��������г���1,��ô�ڴ˴���ͼ
			for (int i = 0; i < horizontal_max; i++) {
				if (inline.charAt(i) == '1') {
					count++;
					if (cache == null) {
						cur_map[rows][i] = getRandom(imageUrl);
						cache = cur_map[rows][i];
					} else {
						cur_map[rows][i] = cache;
						cache = null;
					}
					System.out.print(1);
				} else {
					cur_map[rows][i] = null;
					System.out.print(" ");
				}
			}
			System.out.println();
			rows++;
		}

		if (count % 2 != 0)
			throw new IllegalStateException("�����ļ��е�1Ӧ��Ϊż����");

		if (rows != vertical_max)
			throw new IllegalStateException("�����ļ��������ԣ�Ӧ��Ϊ" + horizontal_max
					+ "��");
		if(reader != null)
		    reader.close();
		return cur_map;

	}

	public static Point mapToLocation(int x, int y) {
		Point dim = new Point();
		dim.x = x * PIC_SIZE;
		dim.y = y * PIC_SIZE;
		return dim;
	}

	public static Point mapToLocation(Point dim) {
		return mapToLocation(dim.x, dim.y);
	}

	public static Point mapToCoordination(int x, int y) {
		Point point = new Point();
		point.x = x / PIC_SIZE;
		point.y = y / PIC_SIZE;
		return point;
	}
	
	public static Point mapToCoordination(Point p){
		return mapToCoordination(p.x, p.y);
	}

	private String getRandom(String url) {
		File file = new File(url);
		File files[] = null;

		if (!file.isDirectory())
			throw new IllegalArgumentException("url������Ŀ¼");

		//���˵�����ͼƬ��ʽ���ļ�
		else {
			files = file.listFiles(new FileFilter() {
				@Override
				public boolean accept(File pathname) {
					String path = pathname.getAbsolutePath();
					return path.endsWith("bmp")
							|| path.endsWith("gif") || path.endsWith("jpeg")
							|| path.endsWith("png");
				}

			});
		}

		int random = (int) (Math.random() * files.length);

		return files[random].getAbsolutePath();
	}

	public static LinkedList<Point> getMiddlePoints(LinkedList<Point> points) {
		LinkedList<Point> list = new LinkedList<Point>();
		for (Iterator<Point> iterator = points.iterator(); iterator.hasNext();) {
			Point name = iterator.next();
			name = LocationManager.mapToLocation(name);
			name.x += PIC_SIZE / 2;
			name.y += PIC_SIZE / 2;
			list.add(name);
		}
		return list;
	}
}
