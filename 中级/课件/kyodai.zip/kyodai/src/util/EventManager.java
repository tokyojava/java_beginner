package util;

import gui.MainPanel;

import java.awt.Color;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.LinkedList;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;

import multithreadedsupport.GameObserver;
import multithreadedsupport.TimeController;
import constants.GUIConstant;

public class EventManager implements ActionListener, MouseListener, GUIConstant {

	final public static EventManager manager = new EventManager();
	public static long last;
	public static int max;
	public static int hit;

	//the pressed buttons are stored in a fifo queue
	MainPanel button[] = new MainPanel[2];
	public static String[][] str;
	public static Thread t;
	public static Thread o;
	private static Border b = BorderFactory.createBevelBorder(
			BevelBorder.RAISED, Color.black, Color.black);

	public EventManager() {
		init();
	}

	/**
	 * do some initialization work for the following clicks to work
	 */
	private void init() {
		button[0] = new MainPanel();
		button[1] = new MainPanel();
		button[0].url = "b1";
		button[1].url = "b2";
	}

	@Override
	/**
	 * shows the logic of what happens when a button is clicked
	 */
	public void actionPerformed(ActionEvent e) {

	}

	/**
	 * this method deletes the identical buttons,reset the bitmap that stores
	 * the url of the pictures and drawlines to show how buttons are deleted 
	 * according to the game rules
	 * @param frame the panel
	 * @param points the buttons to be deleted in a coordination way
	 */
	public void del(String[][] map, JPanel frame, LinkedList<Point> points,
			MainPanel button1, MainPanel button2) {

		Point p1 = LocationManager.mapToCoordination(button1.getX(), button1
				.getY());
		Point p2 = LocationManager.mapToCoordination(button2.getX(), button2
				.getY());
		String temp = map[p1.y][p1.x];
		if (temp.contains("bomb")) {
			gui.Main.bomb_c++;
			gui.Main.bomb.setEnabled(true);
			gui.Main.a.append("win an extra bomb,now you have "
					+ gui.Main.bomb_c + " bombs\n");
		}
		if (temp.contains("hint")) {
			gui.Main.hint_c++;
			gui.Main.hint.setEnabled(true);
			gui.Main.a.append("win an extra hint,now you have "
					+ gui.Main.hint_c + " hints\n");
		}
		if (temp.contains("reset")) {
			gui.Main.reset_c++;
			gui.Main.reset.setEnabled(true);
			gui.Main.a.append("win an extra reset,now you have "
					+ gui.Main.reset_c + " resets\n");
		}
		map[p1.y][p1.x] = null;
		map[p2.y][p2.x] = null;
		SoundManager.elec.play();
		DrawLineManager.drawLine(frame, points);
		init();
		if (frame.getComponentCount() < 10)
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

		frame.remove(button1);
		frame.remove(button2);
		gui.Main.remain.setText("ʣ" + frame.getComponentCount() + "��");
		frame.repaint();
	}

	/**
	 * @param frame
	 * @param panel
	 * @throws IOException
	 */
	public static void gameBegin(final JFrame frame, final JPanel panel,
			String path) {

		gui.Main.auto_mode = false;

		t = new TimeController(panel);
		t.start();

		//�������Ƿ�ȫ��������
		o = new GameObserver(t, panel);
		o.start();

		LocationManager manager = LocationManager.getInstance();
		gui.Main.curFile = path;
		String[][] str = null;
		try {
			str = manager.buildMap(gui.Main.curFile, "src/llk");
		} catch (IOException e) {
			e.printStackTrace();
		}
		LocationManager.mess(str);
		panel.removeAll();
		for (int i = 0; i < str.length; i++) {
			for (int j = 0; j < str[i].length; j++) {
				if (str[i][j] != null) {
					Point dim = LocationManager.mapToLocation(j, i);
					panel.add(new MainPanel(str[i][j], dim.x, dim.y, panel));
				}
			}
		}
		EventManager.str = str;
		SoundManager.start.play();
		SoundManager.bg.loop();

		/**
		 * restore states here
		 */
		restoreStates(frame, panel);
		gui.Main.remain.setText("ʣ" + panel.getComponentCount() + "��");
	}

	/**
	 * restore states after game overs
	 * @param panel
	 */
	public static void gameOverRestore(final JPanel panel) {
		gui.Main.remain.setText("�վ�");
		gui.Main.reset.setEnabled(false);
		gui.Main.hint.setEnabled(false);
		gui.Main.bomb.setEnabled(false);
		gui.Main.bar.setValue(time_scale);
		panel.removeAll();
		panel.repaint();
		SoundManager.bg.stop();
	}

	/**
	 * restore all available variables to an initialized state
	 * @param frame
	 * @param panel
	 */
	public static void restoreStates(final JFrame frame, final JPanel panel) {
		gui.Main.bar.setValue(time_scale);
		gui.Main.reset.setEnabled(true);
		gui.Main.hint.setEnabled(true);
		gui.Main.bomb.setEnabled(true);
		gui.Main.auto_mode = false;
		TimeController.timeout = false;
		gui.Main.bomb_c = 3;
		gui.Main.reset_c = 3;
		gui.Main.hint_c = 3;
		gui.Main.a.setText("");
		gui.Main.points = 0;
		gui.Main.showPoint.setText("�밴��ʼ");
		frame.repaint();
		panel.repaint();
		last = System.currentTimeMillis();
		max = 0;
		hit = 0;
	}

	@Override
	public void mouseClicked(MouseEvent e) {
	}

	@Override
	public void mouseEntered(MouseEvent e) {
	}

	@Override
	public void mouseExited(MouseEvent e) {
	}

	@Override
	public void mousePressed(MouseEvent e) {
		MainPanel a = (MainPanel) e.getSource();
		a.setBorder(b);
		a.repaint();
		button[0].setBorder(null);
		button[0].repaint();
		SoundManager.sel.play();

		JPanel frame = a.frame;

		boolean isDeleted = false;
		LinkedList<Point> points = null;

		if (a != button[1]) {
			button[0] = button[1];
			button[1] = a;

			for (int i = 0; i < 1; i++) {
				if (button[0].url.equalsIgnoreCase(button[1].url)) {
					if ((points = Rules.sameRowOrColumn(EventManager.str,
							button[0], button[1])) != null) {
						isDeleted = true;
						break;
					}
					if ((points = Rules.notTheSameRowOrColumn(EventManager.str,
							button[0], button[1])) != null) {
						isDeleted = true;
					}
				}
			}
		}

		//���������Ҫ����
		if (isDeleted) {
			del(str, frame, points, button[0], button[1]);
			gui.Main.bar.setValue(time_scale);
			gui.Main.bar.setString(time_scale + "��");
			frame.repaint();
		}
	}

	@Override
	public void mouseReleased(MouseEvent e) {
	}
}
