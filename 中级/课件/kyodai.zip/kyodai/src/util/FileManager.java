package util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import constants.GUIConstant;

public class FileManager implements GUIConstant, ActionListener {
	public static int getButtonCounts(String file) throws IOException {
		BufferedReader reader = new BufferedReader(new FileReader(file));
		String inline = "";
		int rows = 0;
		int count = 0;

		while ((inline = reader.readLine()) != null) {
			inline = inline.substring(0, inline.lastIndexOf('0') + 1);
			if (inline.length() != horizontal_max)
				throw new IllegalStateException("��" + rows + "�г��ִ���");

			//��������г���1,��ô�ڴ˴���ͼ
			for (int i = 0; i < horizontal_max; i++) {
				if (inline.charAt(i) == '1')
					count++;
			}
			rows++;
		}
	
		return count;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		/**
		 * ��ͼѡ�񽫵���һ��ѡ���
		 */
		final JFrame frame = new JFrame("ѡ���ͼ");
		frame.setSize(200, 300);
		frame.setLayout(null);
		frame.setLocationRelativeTo(null);
		frame.addWindowListener(new WindowAdapter() {
			//���ô����������ı䴰�ڹرյ�Ĭ����Ϊ
			public void windowClosing(WindowEvent e) {
				frame.dispose();
			}
		});
		frame.setVisible(true);
		//��ȡ���еĵ�ͼ�ļ������û�ѡ��
		File map = new File("maps");
		final File[] maps = map.listFiles();
		final int file_counts = maps.length;

		JTextArea a = new JTextArea();
		a.setEditable(false);
		a.append("��һ����" + file_counts + "�ŵ�ͼ:\n");
		JScrollPane pane = new JScrollPane(a);
		pane.setLocation(0, 0);
		pane.setSize(200, 235);
		frame.add(pane);

		JTextField ic = new JTextField("��ѡ��ڣ�");
		ic.setLocation(5, 236);
		ic.setSize(80, 30);
		ic.setEditable(false);
		ic.setHorizontalAlignment(JTextField.CENTER);
		frame.add(ic);

		final JTextField padding = new JTextField();
		padding.setLocation(90, 236);
		padding.setSize(50, 30);
		frame.add(padding);

		JButton yes = new JButton("ok");
		yes.setLocation(141, 236);
		yes.setSize(50, 30);
		frame.add(yes);

		yes.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String input = padding.getText();
				if (input == null) {
					JOptionPane.showMessageDialog(null, "����������!");
					return;
				}

				int num = 0;
				try {
					num = Integer.valueOf(input);
				} catch (Exception ex) {
					JOptionPane.showMessageDialog(null, "����������!");
					return;
				}
				
				if(num >= file_counts){
					JOptionPane.showMessageDialog(null, "���������_�Ĺ���!");
					return;
				}
					
				gui.Main.curFile = "./maps/";
				gui.Main.curFile +=  maps[num].getName();
				JOptionPane.showMessageDialog(null, maps[num].getName()
						+ "�ѱ��d�룬Ո�c���_ʼ");
				gui.Main.item.setEnabled(true);
				int i1 = gui.Main.curFile.lastIndexOf('/');
				int i2 = gui.Main.curFile.lastIndexOf('.');
				String temp = gui.Main.curFile.substring(i1 + 1,i2);
				gui.Main.item.setText("��ʼ(" + temp + ")");
				frame.dispose();
			}
		});

		for (int i = 0; i < file_counts; i++) {
			String append = "" + i + ":��";
			append += maps[i].getName();
			try {
				append += "   ��"
						+ FileManager
								.getButtonCounts(maps[i].getAbsolutePath());
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			append += "����\n";
			a.append(append);
		}
	}

}
