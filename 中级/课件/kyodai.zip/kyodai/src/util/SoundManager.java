package util;

import gui.Main;

import java.applet.Applet;
import java.applet.AudioClip;

public class SoundManager {

	public static final AudioClip sel = Applet.newAudioClip(SoundManager.class
			.getResource("/sound/sel.wav"));

	public static final AudioClip elec = java.applet.Applet
			.newAudioClip(SoundManager.class.getResource("/sound/elec.wav"));

	public static final AudioClip start = Applet.newAudioClip(Main.class
			.getResource("/sound/start.wav"));

	public static final AudioClip bg = Applet.newAudioClip(Main.class
			.getResource("/sound/bg.mid"));

	public static final AudioClip flystar = Applet.newAudioClip(Main.class
			.getResource("/sound/flystar.wav"));

	public static final AudioClip bomb = Applet.newAudioClip(Main.class
			.getResource("/sound/itemboom.wav"));
	public static final AudioClip notify = Applet.newAudioClip(Main.class
			.getResource("/sound/timenotify.wav"));
	public static final AudioClip clap = Applet.newAudioClip(Main.class
			.getResource("/sound/zhangsheng.wav"));
	public static final AudioClip whistle = Applet.newAudioClip(Main.class
			.getResource("/sound/koushao.wav"));
	public static final AudioClip scream = Applet.newAudioClip(Main.class
			.getResource("/sound/jianjiao.wav"));
	
	
}
