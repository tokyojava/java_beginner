package util;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Point;
import java.util.LinkedList;

import javax.swing.JPanel;

import constants.GUIConstant;

/**
 * ����ר�Ÿ�����ƻ����߼�
 * @author Administrator
 *
 */
public class DrawLineManager implements GUIConstant {

	/**
	���ݸ����Ļ�ͼ��͸����ĵ���л���
	 * @param panel  ��Ҫ���ߵĻ���
	 * @param points  ��Ҫ���ߵĵ�
	 */
	public static void drawLine(JPanel panel, LinkedList<Point> points) {
		Graphics2D g = (Graphics2D) panel.getGraphics();
		g.setStroke(new BasicStroke(6.0f));
		g.setColor(Color.red);
		//one line
		if (points.size() == 2) {
			Point p1 = points.get(0);
			Point p2 = points.get(1);
			g.drawLine(p1.x, p1.y, p2.x, p2.y);
		}

		//two lines,the first point is the transition point
		if (points.size() == 3) {
			Point center = points.get(0);
			Point p1 = points.get(1);
			Point p2 = points.get(2);
			g.drawLine(p1.x, p1.y, center.x, center.y);
			g.drawLine(center.x, center.y, p2.x, p2.y);
		}

		//three lines,the first and the second point are two transition point
		if (points.size() == 4) {
			Point center = points.get(0);
			Point center2 = points.get(1);
			Point p1 = points.get(2);
			Point p2 = points.get(3);
			g.drawLine(p1.x, p1.y, center2.x, center2.y);
			g.drawLine(center.x, center.y, center2.x, center2.y);
			g.drawLine(center.x, center.y, p2.x, p2.y);
		}

		//���������Ļ���
		long now = System.currentTimeMillis();
		if (now - EventManager.last < MAX_INTERVAL) {
			EventManager.hit++;
			EventManager.last = now;
		}

		else {
			if (EventManager.hit > EventManager.max)
				EventManager.max = EventManager.hit;
			EventManager.hit = 1;
			EventManager.last = now;
		}

		int t_max = EventManager.hit;
		if (t_max == 15)
			SoundManager.clap.play();
		if (t_max == 30)
			SoundManager.whistle.play();
		if (t_max == 50)
			SoundManager.scream.play();

		Font f = new Font("Arial", Font.BOLD, 24);
		g.setColor(Color.yellow);
		g.setFont(f);
		final int x = 720;
		final int y = 500;
		//finally,write consecutive hit count
		if (EventManager.max <= EventManager.hit)
			g.drawString(EventManager.hit + "hit", x, y);
		else
			g.drawString(EventManager.hit + "/" + EventManager.max + "hit", x,
					y);
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
