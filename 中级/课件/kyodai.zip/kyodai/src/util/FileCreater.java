package util;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import constants.GUIConstant;

public class FileCreater implements ActionListener, GUIConstant {

	public JFrame frame = new JFrame("������ͼ");
	
	@Override
	public void actionPerformed(ActionEvent e) {
		frame.setSize(600, 500);
		frame.setLayout(null);
		frame.setLocationRelativeTo(null);
		final char bitmap[][] = new char[vertical_max][horizontal_max]; 
		frame.addWindowListener(new WindowAdapter() {
			//���ô����������ı䴰�ڹرյ�Ĭ����Ϊ
			public void windowClosing(WindowEvent e) {
				frame.dispose();
			}
		});
		frame.setVisible(true);
		frame.setResizable(false);
		final JPanel panel = new JPanel();
		panel.setSize(540, 400);
		panel.setLocation(30, 10);

		final JTextField field = new JTextField("�������ְ�");
		field.setSize(160, 30);
		field.setLocation(30, 420);
		frame.add(field);

		JButton ok = new JButton("ok");
		ok.setSize(80, 30);
		ok.setLocation(470, 420);
		frame.add(ok);

		panel.setLayout(new GridLayout(vertical_max, horizontal_max));
		final JButton[] panels = new JButton[vertical_max * horizontal_max];
		for (int i = 0; i < vertical_max; i++) {
			for (int j = 0; j < horizontal_max - 1; j++) {
				int index = i * horizontal_max + vertical_max;
				bitmap[i][j] = '0';
				panels[index] = new JButton();
				JButton curr = panels[index];

				curr.setBackground(Color.red);
				curr.addActionListener(new ActionListener() {

					@Override
					public void actionPerformed(ActionEvent e) {
						JButton b = (JButton) e.getSource();
						if (b.getBackground() == Color.RED){
							b.setBackground(Color.CYAN);
						}
						else
							b.setBackground(Color.red);

						int index = 0;
						for(int i = 0;i < panel.getComponentCount();i++){
							if(panel.getComponent(i) == b){
								index = i;
							}
						}
						
						int row = index / (horizontal_max - 1);
						int col = index % (horizontal_max - 1);
                        char temp = bitmap[row][col];
                        if(temp == '0')
                        	bitmap[row][col] = '1';
                        else
                        	bitmap[row][col] = '0';
					}

				});
				panel.add(curr);
			}
		}

		ok.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				int ret = 0;
				if((ret = checkCount(bitmap)) == -1){
				     JOptionPane.showMessageDialog(null, "�Ɣ�����Ո�����ṩ20����");
				     return;
				}
				else if(ret == -2){
					JOptionPane.showMessageDialog(null, "�Ɣ������ż����Ո�޸�!");
					return;
				}
				
				try {
					BufferedWriter out = new BufferedWriter(new FileWriter(
							"maps/" + field.getText() + ".dat"));
					for (int i = 0; i < vertical_max; i++) {
						for (int j = 0; j < horizontal_max - 1; j++) {
							if (bitmap[i][j] == '1'){
								out.write("1");
							}
							else
								out.write("0");
						}
						out.write("0");
						out.write("\n");
					}
					frame.dispose();
					if (out != null) {
						out.flush();
						out.close();
					}
					JOptionPane.showMessageDialog(null, "�ļ��ф���!");
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			}
			
			private int checkCount(char[][] bitmap) {
				int count = 0;
				for(int i = 0;i < bitmap.length;i++)
					for(int j = 0;j < bitmap[0].length;j++)
						if(bitmap[i][j] == '1')
							count++;
				if(count < 2)
					return -1;
				if(count % 2 != 0)
					return -2;
				return 0;
			}

		});

		frame.add(panel);
	}
	

}
