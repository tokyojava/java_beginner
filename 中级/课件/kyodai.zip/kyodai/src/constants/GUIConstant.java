package constants;

public interface GUIConstant extends GameStatusConstants{

	/*27 * 18 = 486 pics at most
	 * redundant lengths are used as fringes
	 */
	public static final int start_x = 100;
	public static final int start_y =50;
	public static final int Fr_x = 810;
	public static final int Fr_y = 540;
	public static final int advanced_x = 270;
	public static final int advanced_y = 60;
	public static final int header_height = 150;
	public static final int tool_height = 30;
	public static final int PIC_SIZE = 30;
	public final  static int horizontal_max = Fr_x / PIC_SIZE;
	public final  static int vertical_max = Fr_y / PIC_SIZE;
	public final static int ScrollPane_size = 290;
}
