package www.aic;

import java.util.ArrayList;
import java.util.List;

public class ListTest {
	public static void main(String[] args) {
		List list = new ArrayList();
		Person p = new Person();
		p.name = "xiaolu";
		p.age = 20;
		list.add(p);
		
		System.out.println(list.size());//  数组的length等价

		for (Object obj : list) {
			System.out.println(obj);
		}
		
		System.out.println("第0个元素是" + list.get(0));
		
		Person p2 = new Person();
		p2.name = "xiaolu";
		p2.age = 20;
		
		System.out.println(p == p2);
		System.out.println(p.equals(p2));
		
		Person p3 = new Person();
		p3.name = "junji";
		p3.age = 21;
		list.add(p3);
		
		//10000小时，说不定p3已经从程序中消失了
		
		Person p4 = new Person();
		p4.name = "junji";
		p4.age = 21;
		list.add(p4);
		
		System.out.println("junji is at " + list.indexOf(p4));
		
		System.out.println("--------");
		System.out.println(list.contains(p));
		System.out.println(list.contains(p2));
		
		System.out.println(list.isEmpty());
		

	}
}

