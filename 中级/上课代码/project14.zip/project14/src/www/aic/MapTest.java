package www.aic;

import java.util.HashMap;
import java.util.Map;

public class MapTest {
	public static void main(String[] args) {
		Map japaneseDictionary = new HashMap();
		japaneseDictionary.put("あたし", "女性用の私");
		japaneseDictionary.put("あなた","夫の愛称");
		
		System.out.println(japaneseDictionary.get("あたし"));
		System.out.println(japaneseDictionary.get("aaa"));
		
		japaneseDictionary.size();
		japaneseDictionary.isEmpty();
		
		
		
		
		System.out.println("==========================");
		
		Person p = new Person();
		p.name = "xiaolu";
		p.age = 20;
		
		Person p2 = new Person();
		p2.name = "junji";
		p2.age = 21;
		Map personDictionary = new HashMap();
		personDictionary.put(p, "beijing");
		personDictionary.put(p2, "shanghai");
		
		
		Person p3 = new Person();
		p3.name = "xiaolu";
		p3.age = 20;
		
		System.out.println(personDictionary.get(p3));
		
	}
}
