package www.aic;

import java.util.ArrayList;
import java.util.List;


public class GenericTest {
	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		list.add(10);
		
		int a = list.get(0);
		System.out.println(a);
		
		int b = 1;
		Integer c = b;
		int d = c;
		
	}
}
