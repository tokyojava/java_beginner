$(function(){
	$(".view").click(function(){
		window.location = "diary.do";
	});
});