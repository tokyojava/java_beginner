package www.aic;

public class ListenerExample {

	public static void main(String[] args) {
		ZhudiShichang shichang = new ZhudiShichang();
		Xiaofan wang = new Xiaofan("wang");
		Xiaofan tianzhong = new Xiaofan("tanaka");
		
		shichang.addObserver(wang);
		shichang.addObserver(tianzhong);
		
		shichang.inStock(10);
		
	}

}
