package www.aic;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class EventExample {
	public static void main(String[] args) {
		JFrame frame = new JFrame("JCheckBoxTest");
		
		JPanel bigPanel = new JPanel();
		bigPanel.setLayout(new GridLayout(1,2));
		
		frame.add(bigPanel);
		
		JButton button1 = new JButton("button1");
		JButton button2 = new JButton("button2");
		
		bigPanel.add(button1);
		bigPanel.add(button2);
		
		ActionListener listener = new ButtonListener();
		
		button1.addActionListener(listener);
		button2.addActionListener(listener);
		
		frame.setSize(200,200);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}

class ButtonListener implements ActionListener{

	@Override
	public void actionPerformed(ActionEvent e) {
		JButton button = (JButton) e.getSource();
		JOptionPane.showMessageDialog(null, button.getText());
	}
	
}
