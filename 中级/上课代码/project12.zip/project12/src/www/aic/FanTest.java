package www.aic;

import java.awt.Color;

import javax.swing.JFrame;

public class FanTest {
	public static void main(String[] args) {
		JFrame frame = new JFrame("Paint test");

		final FanPanel bigPanel = new FanPanel();
		bigPanel.setBackground(Color.white);

		frame.add(bigPanel);

		frame.setSize(600, 600);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);

		new Thread(new Runnable() {

			@Override
			public void run() {
				while (true) {
					bigPanel.base += 30;
					bigPanel.repaint();
					try {
						Thread.sleep(100);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}

		}).start();
	}
}
