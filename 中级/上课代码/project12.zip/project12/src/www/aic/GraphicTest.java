package www.aic;

import java.awt.Color;
import java.awt.Graphics;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class GraphicTest {

	public static void main(String[] args) {
		JFrame frame = new JFrame("Paint test");

		JPanel bigPanel = new MyPanel();
		bigPanel.setBackground(Color.white);

		frame.add(bigPanel);

		frame.setSize(600, 600);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}

class MyPanel extends JPanel{
	 protected void paintComponent(Graphics g) {
		 super.paintComponent(g);
		 System.out.println("ahahewqewq");
		 g.drawString("Hello AIC", 50, 100);
		 g.drawOval(75, 115, 15, 15);
		 g.drawOval(160, 115, 15, 15);
		 
		 g.drawString("Hello XIAOLU", 120, 100);
		 g.drawOval(30, 30, 200, 200);
		 
		 g.setColor(Color.RED);
		 g.fillRect(105, 180, 50, 10);
		 g.setColor(Color.PINK);
		 g.fillRect(105, 190, 50, 10);
		 
		 g.drawArc(110, 150, 40, 40, 60,60);
	 }
}
