package www.aic;

import java.awt.Graphics;

import javax.swing.JPanel;

public class FanPanel extends JPanel {

	public int base = 0;

	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		int width = getWidth();
		int height = getHeight();
		int radius = 50;

		int xCenter = width / 2 - radius;
		int yCenter = height / 2 - radius;

		g.fillArc(xCenter, yCenter, radius * 2, radius * 2, base, 30);

		g.fillArc(xCenter, yCenter, radius * 2, radius * 2, base + 90, 30);

		g.fillArc(xCenter, yCenter, radius * 2, radius * 2, base + 180, 30);
		g.fillArc(xCenter, yCenter, radius * 2, radius * 2, base + 270, 30);

	}

}
