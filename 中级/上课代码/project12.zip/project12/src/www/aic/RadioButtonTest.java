package www.aic;

import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class RadioButtonTest {
  public static void main(String[] args) {
	JFrame frame = new JFrame();
	
	frame.setSize(120,200);
	frame.setResizable(false);
	frame.setLocationRelativeTo(null);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	
	
	JPanel bigPanel = new JPanel();
	frame.add(bigPanel);
	
	
	ButtonGroup group = new ButtonGroup();
	
	JRadioButton btn1 = new JRadioButton();
	btn1.setText("yes");
	
	JRadioButton btn2 = new JRadioButton();
	btn2.setText("no");
	
	JRadioButton btn3 = new JRadioButton();
	btn3.setText("yes/no");
	
	JRadioButton btn4 = new JRadioButton();
	btn4.setText("irrelevant");
	
	group.add(btn1);
	group.add(btn2);
	group.add(btn3);
	
	bigPanel.add(btn1);
	bigPanel.add(btn2);
	bigPanel.add(btn3);
	bigPanel.add(btn4);
	
	bigPanel.setLayout(new FlowLayout(FlowLayout.LEFT,20,20));
	System.out.println(bigPanel.getLayout());
	
	frame.setVisible(true);
}
}
