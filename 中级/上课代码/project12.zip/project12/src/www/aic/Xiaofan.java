package www.aic;

import java.util.Observable;
import java.util.Observer;

public class Xiaofan implements Observer {

	private String name;

	public Xiaofan(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	@Override
	public void update(Observable o, Object arg) {
		System.out.println("我是" + this.name + "听说驻地市场进了" + arg + "个龙虾，我要去买");
	}

}
