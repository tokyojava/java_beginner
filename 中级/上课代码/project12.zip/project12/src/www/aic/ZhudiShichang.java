package www.aic;

import java.util.Observable;

public class ZhudiShichang extends Observable{
	
	public void inStock(int size){
		System.out.println("我时注定是场进了" + size + "个龙虾");
		setChanged();
		notifyObservers(size);
	}
	
}
