package www.aic;

import java.awt.GridLayout;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class JCheckBoxTest {
public static void main(String[] args) {
	JFrame frame = new JFrame("JCheckBoxTest");
	
	JPanel bigPanel = new JPanel();
	bigPanel.setLayout(new GridLayout(2,2));

	for(int i = 0;i < 4;i++){
		JCheckBox box = new JCheckBox();
		box.setText("option" + i);
		bigPanel.add(box);
	}
	
	
	frame.add(bigPanel);
	
	frame.setSize(200,200);
	frame.setLocationRelativeTo(null);
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	frame.setVisible(true);
}
}
