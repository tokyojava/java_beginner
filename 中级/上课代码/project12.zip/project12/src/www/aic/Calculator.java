package www.aic;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;

public class Calculator {
	
	public static JTextField field = new JTextField("90.0", 20);
	public Calculator() {

		JFrame frame = new JFrame();

		JPanel bigPanel = new JPanel();
		bigPanel.setLayout(new BorderLayout(20, 20));

		int gap = 20;
		Border border = BorderFactory.createEmptyBorder(gap, gap, gap, gap);
		bigPanel.setBorder(border);

		JPanel textJPanel = new JPanel();
		textJPanel.setLayout(new GridLayout());
		
		
		field.setHorizontalAlignment(JTextField.RIGHT);
		textJPanel.add(field);

		field.setFont(new Font("Monospaced", Font.BOLD + Font.ITALIC, 16));

		JPanel numberJPanel = new JPanel();
		numberJPanel.setBackground(Color.PINK);
		numberJPanel.setBorder(BorderFactory.createLineBorder(Color.YELLOW, 5));

		numberJPanel.setLayout(new GridLayout(4, 3, 5, 5));
		for (int i = 0; i < 10; i++) {
			numberJPanel.add(new MyButton(i + ""));
		}

		JButton dotButton = new MyButton(".");
		numberJPanel.add(dotButton);
		JButton equalsButton = new MyButton("=");
		numberJPanel.add(equalsButton);

		JPanel signJPanel = new JPanel();
		signJPanel.setBackground(Color.magenta);
		signJPanel.setLayout(new GridLayout(4, 1, 5, 5));

		JButton divideButton = new MyButton("/");
		signJPanel.add(divideButton);

		JButton minusButton = new MyButton("-");
		signJPanel.add(minusButton);

		JButton multiplyButton = new MyButton("*");
		signJPanel.add(multiplyButton);

		JButton addButton = new JButton("+");
		signJPanel.add(addButton);

		bigPanel.add(textJPanel, BorderLayout.NORTH);
		bigPanel.add(numberJPanel, BorderLayout.CENTER);
		bigPanel.add(signJPanel, BorderLayout.WEST);

		frame.add(bigPanel);
		frame.setTitle("Calculator");
		frame.setSize(300, 300);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon icon = new ImageIcon("/Users/qiucheng/java.jpg");
		frame.setIconImage(icon.getImage());
		frame.setVisible(true);

		Font[] fonts = GraphicsEnvironment.getLocalGraphicsEnvironment()
				.getAllFonts();
		for (Font font : fonts) {
			System.out.println(font);
		}

	}

	public static void main(String[] args) {
		Calculator frame = new Calculator();

	}
}

class MyButton extends JButton{
	
	private static final CalculatorButtonListener listener = new CalculatorButtonListener();
	public MyButton(String mark){
		this.setText(mark);
		addActionListener(listener);
	}
}

class CalculatorButtonListener implements ActionListener {
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton source = (JButton) e.getSource();
		JTextField field = Calculator.field;
		
		if(source.getText().equals(".")){
			field.setText("");
			return;
		}
		
		field.setText(field.getText() + source.getText());
	}

}
