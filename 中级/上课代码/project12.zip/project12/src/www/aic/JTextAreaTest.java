package www.aic;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class JTextAreaTest {

	public static void main(String[] args) {
		JFrame frame = new JFrame("JCheckBoxTest");

		JPanel bigPanel = new JPanel();
		
		JTextArea area = new JTextArea(5, 20);
		area.setText("THis is tokyo welcome to tokyo Olympics Tokyo is fun");
		area.setLineWrap(true);
		area.setWrapStyleWord(false);
		
		bigPanel.add(area);
		
		
		frame.add(bigPanel);
		
		frame.setSize(300, 200);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}
}
