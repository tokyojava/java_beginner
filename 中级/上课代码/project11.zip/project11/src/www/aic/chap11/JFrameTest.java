package www.aic.chap11;

import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class JFrameTest {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		// 设置标题
		frame.setTitle("test");
		// 设置尺寸
		frame.setSize(1000, 1000);

		// 居中
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		System.out.println(panel.getLayout());
		panel.setLayout(new FlowLayout(FlowLayout.LEFT, 15, 20));
		
		
		frame.add(panel);

		panel.add(new JButton("aaaaaaaaaaaaaaaaaaaaa"));
		for(int i = 0;i < 20;i++){
			JButton button = new JButton("hello" + i);
			panel.add(button);
		}
		
		JLabel label = new JLabel("you cannot press me, I am only a label");
		panel.add(label);
		
		JTextField field = new JTextField("Please input something");
		panel.add(field);
		// 设置显式
		frame.setVisible(true);	
	}
}
