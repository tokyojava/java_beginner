package www.aic.chap11;

import java.awt.BorderLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class BorderLayoutClass {

	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(230, 150);
		frame.setLocationRelativeTo(null);
		frame.setTitle("GridLayout");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel panel = new JPanel();
		System.out.println(panel.getLayout());

		panel.setLayout(new BorderLayout());

		JButton north = new JButton("North");
		JButton south = new JButton("South");
		JButton east = new JButton("East");
		JButton west = new JButton("West");
		JButton center = new JButton("Center");
		panel.add(north,BorderLayout.NORTH);
		panel.add(south,BorderLayout.SOUTH);
		panel.add(east,BorderLayout.EAST);
		panel.add(west,BorderLayout.WEST);
		panel.add(center,BorderLayout.CENTER);
		frame.add(panel);
		frame.setResizable(false);
		
		frame.setVisible(true);
	}

}
