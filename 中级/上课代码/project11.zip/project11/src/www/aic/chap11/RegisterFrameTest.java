package www.aic.chap11;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GraphicsEnvironment;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class RegisterFrameTest {
	public static void main(String[] args) {
		JFrame frame = new JFrame();
		frame.setSize(200, 150);
		frame.setLocationRelativeTo(null);
		frame.setTitle("AIC registration");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel bigPanel = new JPanel();
		bigPanel.setLayout(new BorderLayout());
		frame.add(bigPanel);
		
		Font monospace = new Font("Monospaced", Font.BOLD + Font.ITALIC, 20);

		JPanel panel = new JPanel();
		bigPanel.add(panel, BorderLayout.CENTER);

		System.out.println(panel.getLayout());
		panel.setLayout(new FlowLayout(FlowLayout.LEFT));

		JLabel name = new JLabel("name");
		JTextField nameField = new JTextField("xiaolu", 10);
		nameField.setFont(monospace);
		// nameField.setFocusable(true);

		JLabel age = new JLabel("age");
		
		JLabel empty = new JLabel(" ");
		JTextField ageField = new JTextField("20", 10);

		final JButton registerButton = new JButton("Register");
		registerButton.setForeground(Color.BLUE);
		registerButton.setBackground(Color.YELLOW);
		
		panel.add(name);
		panel.add(nameField);
		panel.add(age);
		panel.add(empty);
		panel.add(ageField);

		JPanel panel2 = new JPanel();
		bigPanel.add(panel2, BorderLayout.SOUTH);
		panel2.add(registerButton);
		System.out.println(registerButton);
		
		JButton cancelButton = new JButton("reset");
		panel2.add(cancelButton);

		ButtonListener listener =  new ButtonListener();
		registerButton.addActionListener(listener);
		cancelButton.addActionListener(listener);
		frame.setVisible(true);
		
		GraphicsEnvironment g = GraphicsEnvironment.getLocalGraphicsEnvironment();
		for(Font font: g.getAllFonts()){
			System.out.println(font);
		}
	}
	
}
