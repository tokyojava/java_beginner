package www.aic.chap11;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class ButtonListener implements ActionListener {
	public void actionPerformed(ActionEvent e) {
		JButton source = (JButton) e.getSource();
		if (source.getText().equals("Register")) {
			JOptionPane.showMessageDialog(null, "Register!!!");
		} else {
			JOptionPane.showMessageDialog(null, "Reset!!!");
		}
	}
}
