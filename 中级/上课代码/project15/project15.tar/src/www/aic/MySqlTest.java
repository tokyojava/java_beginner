package www.aic;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MySqlTest {
	
	private static boolean isDebug = false;
	
	public static void main(String[] args) throws IOException {
//		insertPerson();
		
//		List<Person> persons = getPersons();
//		for(Person p:persons){
//			System.out.println(p);
//		}
		createTable();
	}
	
	private static String readSql(String file) throws IOException{
		StringBuilder builder = new StringBuilder();
		BufferedReader reader = new BufferedReader(new FileReader(file));
		int lineNumber = 0;
		while(true){
			String line = reader.readLine();
			if(line == null)
				break;
			if(isDebug)
				System.out.println(lineNumber++ + ":" + line);
			builder.append(line);
		}
		reader.close();
		return builder.toString();
	}
	
	private static void createTable(){
		Connection conn = null;
		PreparedStatement pstmt = null;
		try{
			conn = getConnection();
			String sql = readSql("address.sql");
			pstmt = conn.prepareStatement(sql);
			pstmt.executeUpdate();
		}catch(Exception e){
			e.printStackTrace();
		}
		finally{
			try {
				close(pstmt,conn,null);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	private static void updatePerson(int id,int age){
		
	}
	
	private static void deletePerson(int id){
		
	}

	private static void insertPerson() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		try {
			conn = getConnection();
			String sql = "insert into person(name,weight,age)  values(?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "xiaoqiang");
			pstmt.setDouble(2, 60);
			pstmt.setInt(3, 20);

			pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				close(pstmt, conn, null);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	private static List<Person> getPersons() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rst = null;
		
		List<Person> ret = new ArrayList<Person>();
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement("select * from person");
			rst = pstmt.executeQuery();
			while(rst.next()){
				Person p = new Person();
				p.setId(rst.getInt("id"));
				p.setName(rst.getString("name"));
				p.setAge(rst.getInt("age"));
				p.setBirthday(rst.getDate("birthday"));
				p.setWeight(rst.getDouble("weight"));
				ret.add(p);
			}
			return ret;
		} catch (Exception e) {
			e.printStackTrace();
			return new ArrayList<Person>();
		} finally {
			try {
				close(pstmt, conn, rst);
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	private static Connection getConnection() throws ClassNotFoundException,
			SQLException {
		Class.forName("com.mysql.jdbc.Driver");

		String userName = "root";
		String password = "root";
		Connection conn = DriverManager.getConnection(
				"jdbc:mysql://localhost/aic", userName, password);
		return conn;
	}

	private static void close(PreparedStatement pstmt, Connection conn,
			ResultSet rst) throws SQLException {
		if (rst != null)
			rst.close();
		if (pstmt != null)
			pstmt.close();
		if (conn != null)
			conn.close();
	}

}
