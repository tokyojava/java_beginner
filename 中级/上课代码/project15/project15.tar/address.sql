CREATE TABLE `aic`.`address` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `city` VARCHAR(45) NULL,
  `street` VARCHAR(45) NULL,
  `person_id` INT(11) NULL,
  PRIMARY KEY (`id`));
