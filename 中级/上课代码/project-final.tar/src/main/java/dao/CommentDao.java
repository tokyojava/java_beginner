package dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import model.Comment;

public class CommentDao extends CommonDao {

	public void saveComment(Comment comment) throws SQLException {
		try {
			conn = getConnection();
			String sql = "insert into comment(content,create_time,commenter,article_id) values(?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, comment.getContent());
			pstmt.setTimestamp(2, new Timestamp(System.currentTimeMillis()));
			pstmt.setInt(3, comment.getCommenterId());
			pstmt.setInt(4, comment.getArticleId());
			pstmt.executeUpdate();
		} finally {
			close();
		}
	}

	public List<Comment> getAllComments(int article) throws SQLException {
		try {
			List<Comment> comments = new ArrayList<Comment>();
			conn = getConnection();
			String sql = "select * from comment where article_id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, article);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				Comment comment = new Comment();
				comment.setId(rst.getInt("id"));
				comment.setArticleId(rst.getInt("article_id"));
				comment.setCommenterId(rst.getInt("commenter"));
				comment.setContent(rst.getString("content"));
				comment.setCreateTime(rst.getTimestamp("create_time"));

				comments.add(comment);
			}
			return comments;
		} finally {
			close();
		}
	}

}
