package dao;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import model.Diary;

public class DiaryDao extends CommonDao {

	public void saveNewDiary(Diary diary) throws SQLException {
		try {
			conn = getConnection();
			String sql = "insert into diary(title,content,person_id,create_time) values(?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, diary.getTitle());
			pstmt.setString(2, diary.getContent());
			pstmt.setInt(3, diary.getPersonId());
			pstmt.setTimestamp(4, new Timestamp(System.currentTimeMillis()));
			pstmt.executeUpdate();
		} finally {
			close();
		}
	}

	public List<Diary> getAllDiaries(int person_id) throws SQLException {
		List<Diary> ret = new ArrayList<Diary>();
		try {
			String sql = "select * from diary where person_id=? order by create_time desc";// descend
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, person_id);
			rst = pstmt.executeQuery();
			while (rst.next()) {
				Diary d = new Diary();
				d.setId(rst.getInt("id"));
				d.setCreateTime(rst.getTimestamp("create_time"));
				d.setPersonId(person_id);
				d.setContent(rst.getString("content"));
				d.setTitle(rst.getString("title"));
				ret.add(d);
			}
			return ret;

		} finally {
			close();
		}
	}

	public Diary getDiaryById(int article_id) throws SQLException {
		try {
			conn = getConnection();
			String sql = "select * from diary where id=?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, article_id);

			rst = pstmt.executeQuery();
			rst.next();
			Diary ret = new Diary();
			ret.setId(rst.getInt("id"));
			ret.setCreateTime(rst.getTimestamp("create_time"));
			ret.setPersonId(rst.getInt("person_id"));
			ret.setTitle(rst.getString("title"));
			ret.setContent(rst.getString("content"));
			return ret;

		} finally {
			close();
		}

	}

}
