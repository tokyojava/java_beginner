package service;

import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;

import model.Comment;
import dao.CommentDao;

public class CommentService {
	private CommentDao dao = new CommentDao();
	public void saveComment(Comment comment) throws SQLException{
		dao.saveComment(comment);
	}
	
	public List<Comment> getAllComments(int article) throws SQLException {
		List<Comment> comments = dao.getAllComments(article);
		for(Comment comm:comments){
			comm.setContent(convert(comm.getContent()));
		}
		return comments;
	}
	private static String convert(String con){
		return con.replaceAll("\n", "<br/>");
	}
}
