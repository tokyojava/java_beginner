package service;

import java.sql.SQLException;
import java.util.List;

import dao.DiaryDao;
import model.Diary;

public class DiaryService {

	private DiaryDao dao = new DiaryDao();

	public void saveNewDiary(Diary diary) throws SQLException {
		dao.saveNewDiary(diary);
	}

	public List<Diary> getAllDiaries(int person_id) throws SQLException {
		List<Diary> diaries = dao.getAllDiaries(person_id);
		for (Diary d : diaries) {
			d.setContent(changeNewLineToBr(d.getContent()));
		}
		return diaries;
	}

	public Diary getDiaryById(int article_id) throws SQLException {
		Diary diary = dao.getDiaryById(article_id);
		diary.setContent(changeNewLineToBr(diary.getContent()));
		return diary;
	}

	private static String changeNewLineToBr(String str) {
		return str.replaceAll("\n", "<br/>");
	}

}
