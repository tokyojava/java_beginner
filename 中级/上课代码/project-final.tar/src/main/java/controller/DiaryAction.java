package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Comment;
import model.Diary;
import service.CommentService;
import service.DiaryService;

public class DiaryAction extends JspDispatcher{
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		int article_id = Integer.parseInt(req.getParameter("article_id"));
		Diary d;
		List<Comment> comments;
		try {
			d = new DiaryService().getDiaryById(article_id);
			comments = new CommentService().getAllComments(article_id);
		} catch (SQLException e) {
			System.out.println(e.getMessage());
			throw new ServletException(e);
		}
		req.setAttribute("diary", d);
		req.setAttribute("comments", comments);
		super.doGet(req, resp);
	}
}
