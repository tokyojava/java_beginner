package controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.Comment;
import model.Person;
import service.CommentService;

public class PostCommentAction extends JspDispatcher {
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String content = req.getParameter("content");
		int article_id = Integer.parseInt(req.getParameter("article_id"));
		Person p = (Person) req.getSession().getAttribute("user");
		Comment comment = new Comment();
		comment.setArticleId(article_id);
		comment.setCommenterId(p.getId());
		comment.setContent(content);
		try {
			new CommentService().saveComment(comment);
			resp.sendRedirect("diary.do?article_id=" + article_id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			throw new ServletException(e);
		}
	}
}
