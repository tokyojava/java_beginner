$(function(){
	$("#submit").click(function(){
		$("#register_form").submit();
	});
	
});