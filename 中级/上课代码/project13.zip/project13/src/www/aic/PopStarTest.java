package www.aic;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class PopStarTest {
	public static void main(String[] args) throws IOException {
		PopStar p1 = new PopStar("junji", "riben xiaobangwang");
		PopStar p2 = new PopStar("xiaolu", "chidai xiaobangwang");

		BufferedWriter writer = new BufferedWriter(new FileWriter("pop.txt"));
		writer.write(p1.toString());
		writer.write("\n");
		writer.write(p2.toString());
		writer.flush();
		writer.close();

	}
}

class PopStar {
	public String name;
	public String description;

	public PopStar(String name, String description) {
		super();
		this.name = name;
		this.description = description;
	}

	public String toString() {
		return name + ":" + description;
	}

}