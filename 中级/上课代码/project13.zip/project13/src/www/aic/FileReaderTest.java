package www.aic;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class FileReaderTest {
	public static void main(String[] args) throws IOException {
		BufferedReader bf = null;
		FileReader in = new FileReader(new File("test.txt"));
		bf = new BufferedReader(in);

		int read = -1;
		while ((read = bf.read()) != -1) {
			System.out.print(read + " ");
			System.out.println((char) read + " ");
		}
		bf.close();
	}
}
