package www.aic;

import java.io.File;
import java.io.IOException;

public class FileTest {
	public static void main(String[] args) throws IOException {
		File file = new File("/Users/qiucheng/Desktop");

		System.out.println(file.exists());
		System.out.println(file.isDirectory());

		File pork = new File(file, "porkFactory.jar");
		pork = new File("/Users/qiucheng/Desktop", "porkFactory.jar");
		System.out.println(pork.exists());

		System.out.println(pork.getName());
		System.out.println(pork.getAbsolutePath());

		pork.renameTo(new File(file, "P.jar"));
		
		
		File f = new File("/Users/qiucheng/Desktop/test");
		if(!f.exists()){
			f.mkdir();
		}
	}
}