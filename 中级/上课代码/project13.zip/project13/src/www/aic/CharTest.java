package www.aic;

public class CharTest {

	public static void main(String[] args) {
		char a = 'あ';
		int b = 'あ';
		int c = 'い';
		System.out.println(a);
		System.out.println(b);
		System.out.println((char)c);
		
		System.out.println((int)'我');
	}

}
