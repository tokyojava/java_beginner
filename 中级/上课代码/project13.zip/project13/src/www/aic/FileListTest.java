package www.aic;

import java.io.File;
import java.io.FilenameFilter;

public class FileListTest {
	public static void main(String[] args) {
		File f = new File("/Users/qiucheng");
		String[] files = f.list(new MyFileNameFilter());
		for (String current : files) {
			if (!current.startsWith("."))
				System.out.println(current);
		}
	}
}

class MyFileNameFilter implements FilenameFilter{

	@Override
	public boolean accept(File dir, String name) {
		return !name.startsWith(".");
	}
	
}