package www.aic;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileInputTest {
	public static void main(String[] args) throws IOException {
		FileInputStream in = new FileInputStream(new File("test.txt"));

		int read = -1;
		while ((read = in.read()) != -1) {
			System.out.print(read + " ");
			System.out.println((char) read + " ");
		}
		in.close();
	}
}
